#pragma once
#include <Arduino.h>
#include <mbedtls/gcm.h>
#include <mbedtls/base64.h>

class SecureChannel {
public:
  SecureChannel(Stream& io) : io_(io), tx_counter_(1), salt_set_(false) {
    memset(key_, 0, sizeof(key_));
    memset(salt_, 0, sizeof(salt_));
  }

  bool begin(const uint8_t* key, size_t key_len, const uint8_t* salt_opt=nullptr) {
    if (!(key_len==16 || key_len==24 || key_len==32)) return false;
    memcpy(key_, key, key_len);
    key_len_ = key_len;
    if (salt_opt) {
      memcpy(salt_, salt_opt, 8);
      salt_set_ = true;
    } else {
      for (int i=0;i<8;i++) salt_[i] = (uint8_t)random(0,256);
      salt_set_ = true;
    }
    io_.println("SC:READY");
    return true;
  }

  bool sendJSON(const String& json) {
    if (!salt_set_) return false;
    uint8_t nonce[12];
    memcpy(nonce, salt_, 8);
    nonce[8] = (tx_counter_ >> 24) & 0xFF;
    nonce[9] = (tx_counter_ >> 16) & 0xFF;
    nonce[10]= (tx_counter_ >> 8)  & 0xFF;
    nonce[11]= (tx_counter_ >> 0)  & 0xFF;
    tx_counter_++;

    mbedtls_gcm_context gcm;
    mbedtls_gcm_init(&gcm);
    int rc = mbedtls_gcm_setkey(&gcm, MBEDTLS_CIPHER_ID_AES, key_, key_len_*8);
    if (rc!=0) { mbedtls_gcm_free(&gcm); return false; }

    const uint8_t* pt = (const uint8_t*)json.c_str();
    size_t pt_len = json.length();

    std::unique_ptr<uint8_t[]> ct(new uint8_t[pt_len]);
    uint8_t tag[16];
    rc = mbedtls_gcm_crypt_and_tag(&gcm, MBEDTLS_GCM_ENCRYPT,
                                   pt_len, nonce, sizeof(nonce),
                                   nullptr, 0, pt, ct.get(), sizeof(tag), tag);
    if (rc!=0) { mbedtls_gcm_free(&gcm); return false; }

    size_t raw_len = sizeof(nonce) + pt_len + sizeof(tag);
    std::unique_ptr<uint8_t[]> raw(new uint8_t[raw_len]);
    memcpy(raw.get(), nonce, sizeof(nonce));
    memcpy(raw.get()+sizeof(nonce), ct.get(), pt_len);
    memcpy(raw.get()+sizeof(nonce)+pt_len, tag, sizeof(tag));

    size_t out_len=0;
    mbedtls_base64_encode(nullptr, 0, &out_len, raw.get(), raw_len);
    std::unique_ptr<uint8_t[]> b64(new uint8_t[out_len+1]);
    rc = mbedtls_base64_encode(b64.get(), out_len, &out_len, raw.get(), raw_len);
    if (rc!=0) { mbedtls_gcm_free(&gcm); return false; }
    b64.get()[out_len] = 0;

    io_.print("ENC:");
    io_.println((const char*)b64.get());

    mbedtls_gcm_free(&gcm);
    return true;
  }

  bool recvJSON(String& out, uint32_t timeout_ms=10000) {
    const uint32_t t0 = millis();
    while (millis() - t0 < timeout_ms) {
      if (!io_.available()) { delay(2); continue; }
      String line = io_.readStringUntil('\n');
      line.trim();
      if (!line.startsWith("ENC:")) continue;

      String b64 = line.substring(4);
      size_t max_dec = (b64.length()*3)/4 + 4;
      std::unique_ptr<uint8_t[]> buf(new uint8_t[max_dec]);
      size_t dec_len=0;
      int rc = mbedtls_base64_decode(buf.get(), max_dec, &dec_len,
                                     (const unsigned char*)b64.c_str(), b64.length());
      if (rc!=0 || dec_len<12+16) continue;

      uint8_t* nonce = buf.get();
      uint8_t* rest = buf.get()+12;
      size_t rest_len = dec_len-12;
      if (rest_len<16) continue;
      size_t ct_len = rest_len-16;
      uint8_t* ct  = rest;
      uint8_t* tag = rest+ct_len;

      mbedtls_gcm_context gcm;
      mbedtls_gcm_init(&gcm);
      rc = mbedtls_gcm_setkey(&gcm, MBEDTLS_CIPHER_ID_AES, key_, key_len_*8);
      if (rc!=0) { mbedtls_gcm_free(&gcm); continue; }

      std::unique_ptr<uint8_t[]> pt(new uint8_t[ct_len+1]);
      rc = mbedtls_gcm_auth_decrypt(&gcm, ct_len, nonce, 12, nullptr, 0, tag, 16, ct, pt.get());
      mbedtls_gcm_free(&gcm);
      if (rc!=0) continue;

      pt.get()[ct_len] = 0;
      out = String((const char*)pt.get());
      return true;
    }
    return false;
  }

private:
  Stream& io_;
  uint8_t key_[32];
  size_t  key_len_{0};
  uint8_t salt_[8];
  bool    salt_set_;
  uint32_t tx_counter_;
};
